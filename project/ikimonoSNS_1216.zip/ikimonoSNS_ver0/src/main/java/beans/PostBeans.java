package beans;

import java.io.Serializable;

public class PostBeans implements Serializable{
	private int postId;		// --DB:post_id
	private String userId;		// --DB:user_id
	private String dateTime;    // --DB:post_date
	private String caption; 	// --DB:caption
	
	
	public PostBeans() {}
	
	public PostBeans(int postId,String userId,String dateTime,String caption) {
		this.postId = postId;
		this.userId = userId;
		this.dateTime = dateTime;
		this.caption = caption;
	}
	
	
	// getter
	public int getPostId() {
		return postId;
	}
	
	public String getUserId() {
		return userId;
	}
	
	public String getDateTime() {
		return dateTime;
	}
	
	public String getCaption() {
		return caption;
	}
	
	
	
	// setter
	public void setPostId(int postId) {
		this.postId = postId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	
	public void setCaption(String caption) {
		this.caption = caption;
	}

}
