package beans;

import java.io.Serializable;

// Users情報を保持するJavaBeans
public class UsersBeans implements Serializable {
	
	private String id;  // --DB:user_id
	private String name;  // --DB:user_name
	private String address; // --DB:mail_address
	private String pass;  // --DB:password
		
	public UsersBeans() {}
	
	public UsersBeans(String id) {
		this.id = id;
	}
	
	public UsersBeans(String name,String pass) {
		this.name = name;
		this.pass = pass;
	}
	
	
	// getter
	public String getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getAddress() {
		return address;
	}

	public String getPass() {
		return pass;
	}
	
	
	// setter
	public void setId(String id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public void setPass(String pass) {
		this.pass = pass;
	}

}
