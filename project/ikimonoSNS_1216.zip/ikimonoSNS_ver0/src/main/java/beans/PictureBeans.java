package beans;

import java.io.Serializable;

public class PictureBeans implements Serializable{
	private int picId;
	private String picUrl;
	
	
	public PictureBeans() {}
	
	public PictureBeans(int picId,String picUrl) {
		this.picId = picId;
		this.picUrl = picUrl;
	}
	
	
	// getter
	public int getPicId() {
		return picId;
	}
	
	public String getPicUrl() {
		return picUrl;
	}
	
	
	
	//setter
	public void setPicId(int picId) {
		this.picId = picId;
	}
	
	public void setPicUrl(String picUrl) {
		this.picUrl = picUrl;
	}

}
