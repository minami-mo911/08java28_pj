package beans;

import java.io.Serializable;

public class CategoryBeans implements Serializable{
	private int categoryId;
	private String categoryName;
	
	
	public CategoryBeans() {}
	
	public CategoryBeans(int categoryId,String categoryName) {
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}
	
	
	// getter
	public int getCategoryId() {
		return categoryId;
	}
	
	public String getCategoryName() {
		return categoryName;
	}
	
	
	
	//setter
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
}
