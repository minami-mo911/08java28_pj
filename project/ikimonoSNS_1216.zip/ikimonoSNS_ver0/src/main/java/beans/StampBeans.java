package beans;

import java.io.Serializable;

public class StampBeans implements Serializable {
	private int stampId;
	private String stampName;
	private String stampCode;
	
	
	public StampBeans() {}
	
	public StampBeans(int stampId,String stampName,String stampCode) {
		this.stampId = stampId;
		this.stampName = stampName;
		this.stampCode = stampCode;
	}
	
	
	// getter
	public int getStampId() {
		return stampId;
	}
	
	public String getStampName() {
		return stampName;
	}
	
	public String getStampCode() {
		return stampCode;
	}
	
	
	
	//setter
	public void setStampId(int stampId) {
		this.stampId = stampId;
	}
	
	public void setStampName(String stampName) {
		this.stampName = stampName;
	}
	
	public void setStampCode(String stampCode) {
		this.stampCode = stampCode;
	}

}
