package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.CategoryBeans;
import beans.PostBeans;
import beans.UsersBeans;


public class PostDAO {
    private final String JDBC_URL = "jdbc:h2:~/desktop/SQL/ikimono";
    private final String DB_USER = "sa";
    private final String DB_PASS = "";
    
    
    public List<PostBeans> findAll() {
        List<PostBeans> postList = new ArrayList<>();

        try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("JDBCドライバを読み込めませんでした");
        }

        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            String sql = "SELECT ID, USER_ID, USER_NAME, CAPTION, POST_DATE, GOOD FROM TWEETS ORDER BY ID DESC";
            PreparedStatement pStmt = conn.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String userId = rs.getString("USER_ID");
                String userName = rs.getString("USER_NAME");
                String caption = rs.getString("CAPTION");
                String dateTime = rs.getString("POST_DATE");
                int good = rs.getInt("GOOD");

                PostBeans post = new PostBeans(id, userId, userName, caption, dateTime, good);
                List.add(post);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return postList;
    }
    
    
    
    public boolean create(UsersBeans Users,PostBeans Post,CategoryBeans Category) {
    	try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("JDBCドライバを読み込めませんでした");
        }
    	
    	
    	try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            String sql = "INSERT INTO TWEETS(NAME, TEXT, DATETIME, GOOD) VALUES(?, ?, ?, ?)";
            PreparedStatement pStmt = conn.prepareStatement(sql);
            
            pStmt.setString(1, Users.getName());
            pStmt.setString(2, Post.getCaption());
            pStmt.setString(3, Post.getDateTime());
            pStmt.setInt(4, Category.getGood());
            
            int result = pStmt.executeUpdate();
            return result == 1;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    	
    }

}
