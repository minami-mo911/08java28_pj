package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Post;

public class PostDAO {
    private final String JDBC_URL = "jdbc:h2:~/desktop/workspace/08java28_pj/DB/ikimono";
    private final String DB_USER = "sa";
    private final String DB_PASS = "";

    public List<Post> findAll() {
        List<Post> postList = new ArrayList<>();

        try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("JDBCドライバを読み込めませんでした");
        }

        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            String sql = "SELECT ID, NAME, TEXT, DATETIME, GOOD FROM TWEETS ORDER BY ID DESC";
            PreparedStatement pStmt = conn.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String userName = rs.getString("NAME");
                String text = rs.getString("TEXT");
                String dateTime = rs.getString("DATETIME");
                int good = rs.getInt("GOOD");

                Post post = new Post(id, userName, text, dateTime, good, dateTime);
                postList.add(post);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return postList;
    }

    public boolean create(Post post) {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            String sql = "INSERT INTO TWEETS(NAME, TEXT, DATETIME, GOOD, IMAGE_URL) VALUES(?, ?, ?, ?, ?)";
            PreparedStatement pStmt = conn.prepareStatement(sql);
            pStmt.setString(1, post.getUserName());
            pStmt.setString(2, post.getText());
            pStmt.setString(3, post.getDateTime());
            pStmt.setInt(4, post.getGood());
            pStmt.setString(5, post.getImageUrl());
            int result = pStmt.executeUpdate();
            return result == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean updateGood(int id) {
        try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("JDBCドライバを読み込めませんでした");
        }

        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            String sql = "UPDATE TWEETS SET GOOD = GOOD + 1 WHERE ID = ?";
            PreparedStatement pStmt = conn.prepareStatement(sql);
            pStmt.setInt(1, id);
            int result = pStmt.executeUpdate();
            return result == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
