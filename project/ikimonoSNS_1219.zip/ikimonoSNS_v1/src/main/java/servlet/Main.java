package servlet;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

import beans.Post;
import beans.Users;
import dao.PostDAO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import model.GetPostListLogic;


@WebServlet("/Main")
public class Main extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        GetPostListLogic getPostListLogic = new GetPostListLogic();
        List<Post> postList = getPostListLogic.execute();
        request.setAttribute("postList", postList);

        HttpSession session = request.getSession();
        Users loginUser = (Users) session.getAttribute("loginUser");

        if (loginUser == null) {
            response.sendRedirect("index.jsp");
        } else {
            RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/main.jsp");
            dispatcher.forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        if ("post".equals(action)) {
            Part filePart = request.getPart("image");
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            String imagePath = "uploads/" + fileName;
            filePart.write(getServletContext().getRealPath("/") + imagePath);

            String text = request.getParameter("text");
            HttpSession session = request.getSession();
            Users loginUser = (Users) session.getAttribute("loginUser");

            Post post = new Post(loginUser.getUserName(), text, imagePath);
            PostDAO dao = new PostDAO();
            dao.create(post);
        }

        response.sendRedirect("Main");
    }

}
