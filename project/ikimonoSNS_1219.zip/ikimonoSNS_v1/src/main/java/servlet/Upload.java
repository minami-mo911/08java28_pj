package servlet;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import beans.Post;
import beans.Users;
import dao.PostDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;


@WebServlet("/Upload")
@MultipartConfig(
	    fileSizeThreshold = 1024 * 1024 * 2, 
	    maxFileSize = 1024 * 1024 * 10,      
	    maxRequestSize = 1024 * 1024 * 50    
	)
	public class Upload extends HttpServlet {
	    private static final long serialVersionUID = 1L;

	    private static final String UPLOAD_DIR = "uploads";

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        request.setCharacterEncoding("UTF-8");

	        HttpSession session = request.getSession();
	        Users loginUser = (Users) session.getAttribute("loginUser");

	        if (loginUser == null) {
	            response.sendRedirect("index.jsp");
	            return;
	        }

	        // アップロードディレクトリのパスを明示的に設定
	        String uploadPath = getServletContext().getRealPath("/") + "uploads";
	        File uploadDir = new File(uploadPath);
	        if (!uploadDir.exists()) {
	            uploadDir.mkdirs();
	        }

	        String text = request.getParameter("text");

	        // 画像ファイルの処理
	        String fileName = null;
	        Part filePart = request.getPart("image");
	        if (filePart != null && filePart.getSize() > 0) {
	            fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
	            File file = new File(uploadDir, fileName);
	            filePart.write(file.getAbsolutePath());
	            System.out.println("File saved to: " + file.getAbsolutePath());
	        }

	        String imageUrl = (fileName != null) ? UPLOAD_DIR + "/" + fileName : null;

	        Post post = new Post(loginUser.getUserName(), text, imageUrl);
	        PostDAO dao = new PostDAO();
	        boolean isSuccess = dao.create(post);

	        if (isSuccess) {
	            response.sendRedirect("Main");
	        } else {
	            request.setAttribute("errorMsg", "投稿に失敗しました。");
	            request.getRequestDispatcher("WEB-INF/jsp/main.jsp").forward(request, response);
	        }
	    }
	}
