package beans;

import java.io.Serializable;

public class Post implements Serializable {
    private int id;
    private String userName;
    private String text;
    private String dateTime;
    private int good;
    private String imageUrl; // 画像URL

    public Post() {}

    public Post(int id, String userName, String text, String dateTime, int good, String imageUrl) {
        this.id = id;
        this.userName = userName;
        this.text = text;
        this.dateTime = dateTime;
        this.good = good;
        this.imageUrl = imageUrl;
    }

    public Post(String userName, String text, String imageUrl) {
        this.userName = userName;
        this.text = text;
        this.dateTime = java.time.LocalDateTime.now()
            .format(java.time.format.DateTimeFormatter.ofPattern("yyyy年MM月dd日HH:mm"));
        this.good = 0;
        this.imageUrl = imageUrl;
    }

    public int getId() { return id; }
    public String getUserName() { return userName; }
    public String getText() { return text; }
    public String getDateTime() { return dateTime; }
    public int getGood() { return good; }
    public String getImageUrl() { return imageUrl; }
}
